package com.perscholas.case_study.models;

public class Product {
	
	private int product_id;
	private String name;
	private double price;
	private int quantity_available;

}

