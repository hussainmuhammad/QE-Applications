package com.perscholas.case_study.models;

public class Purchase {
	private int purchase_id;
	private int customer_id;
	private int product_id;
}
