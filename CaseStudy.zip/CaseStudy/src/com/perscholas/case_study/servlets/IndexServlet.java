package com.perscholas.case_study.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.perscholas.case_study.DAO.UserDAO;
import com.perscholas.case_study.models.User;

/**
 * Servlet implementation class IndexServlet
 */
@WebServlet("/IndexServlet")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    private void register(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		RequestDispatcher dispatcher =  request.getRequestDispatcher("register.jsp");
		dispatcher.forward(request, response);
	}
	
    private void registerUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	//Gets values from form
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confPassword");
        Integer returnId = -1; 
        //Github Hashmap solution
        //https://stackoverflow.com/questions/6464931/how-perform-validation-and-display-error-message-in-same-form-in-jsp
        Map<String, String> errorMsg = new HashMap<String, String>();
        
        if(email == null || email.length() < 3) {
        	errorMsg.put("Failure", "Please enter a email");
        }
        else if(errorMsg.isEmpty()){
        	errorMsg.put(email, "email is valid");
        }else {
        	//prompt user to fill out remaining fields
        }
        
        
        if(password == null || password.length() < 7 || !password.contains("^[a-zA-Z0-9_]*$")) {
        	errorMsg.put("Failure", "Enter a valid password");
        }
        else if(errorMsg.isEmpty()) {
        	errorMsg.put(password, "Password is valid");
        }
        else if(password != confirmPassword) {
        	errorMsg.put("Failure", "Password and confirmed password do not match");
        }else {
        	
            User newUser = new User(email , password, confirmPassword);
            UserDAO dao = new UserDAO();
            returnId = dao.registerUser(newUser);
            System.out.println(returnId);
            response.sendRedirect("/index");
//            RequestDispatcher rd = request.getRequestDispatcher("/newCustomerForm");
//			rd.forward(request, response);
        }
               
        
//        System.out.println(newUser);
    
    }
    
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    //This says start my server at index.html
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
			dispatcher.forward(request, response);
			
			String action = request.getServletPath();
			
			try {
	            switch (action) {
	            case "/registerUser":
	                registerUser(request, response);
	                break;
	            case "/register":
	            	register(request, response);
	                break;
	            default:
	        		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
	        		rd.forward(request, response);
	        		break;
	            	}
	            } catch (SQLException ex) {
	                throw new ServletException(ex);
	            }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
        User user = new User();
       // UserDAO userDao = new UserDAO();
        String redirPage = "";
		String action = request.getParameter("action");
        RequestDispatcher dispatcher = null;
        
        if(action.equals("login")) {
    		String email = request.getParameter("email");
            String password = request.getParameter("password");            
            
            if(user != null) { //If user is in DB do the following:
	            	if(user.getPassword().equals(password)) {
	            	redirPage = "IndexServlet?action=loggedIn";
	            	}
	            	
	            	else{ //password is incorrect but user exists, do the following
	            		request.setAttribute("error", "Invalid Credentials");
	            		doGet(request, response);
	            	}
	            
	            	//if no user in DB display error/redirect page
	        		//set error message
            else {
        		request.setAttribute("error", "Invalid Credentials");
        		doGet(request, response);
            		
            	}
            }
           
        }
		doGet(request, response);
        response.sendRedirect("/index");

	}

}
